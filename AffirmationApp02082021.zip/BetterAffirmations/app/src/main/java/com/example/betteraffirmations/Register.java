package com.example.betteraffirmations;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.*;
import java.lang.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.betteraffirmations.ui.login.LoginActivity;
import com.google.android.material.snackbar.Snackbar;

public class Register extends AppCompatActivity {
    DatabaseHelper myDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        myDb = new DatabaseHelper(this);

        final EditText usernameEditText = findViewById(R.id.new_username);
        final EditText passwordEditText = findViewById(R.id.new_password);
        final EditText firstNameEditText = findViewById(R.id.first_name);
        final EditText lastNameEditText = findViewById(R.id.last_name);
        final Button backButton = findViewById(R.id.back);
        final Button confirmButton = findViewById(R.id.confirm);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loadLogin = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(loadLogin);
            }
        });

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = myDb.insertData(firstNameEditText.getText().toString(), lastNameEditText.getText().toString(),
                                usernameEditText.getText().toString(), passwordEditText.getText().toString());
                if (isInserted = true) {
                    Toast.makeText(Register.this, "Account Created", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(Register.this, "Error Fix Fields", Toast.LENGTH_SHORT).show();

                Cursor res = myDb.getAllData();
                if (res.getCount() == 0){
                    showMessage("Error","Not Saved To DataBase");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()){
                    buffer.append("FirstName :"+ res.getString(1)+"\n");
                    buffer.append("LastName :"+ res.getString(2)+"\n");
                    buffer.append("Email :"+ res.getString(3)+"\n");
                    buffer.append("Password :"+ res.getString(4)+"\n\n");
                }
                showMessage("Data",buffer.toString());
                try {
                    wait(100);
                    Intent loadLogin = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(loadLogin);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();

    }


}
# AffirmationApp

README

Affirmation App is also called Better Affirmation Time that is a project with students at the University of Washington
in the Information Technology major. Better Affirmation Time will assist with users remembering affirmations or 
reminders throughout their lives. With daily messages, machine learning is implemented to assist with positive thoughts.

package com.example.betteraffirmations;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.*;
import java.lang.*;

import androidx.appcompat.app.AppCompatActivity;

import com.example.betteraffirmations.ui.login.LoginActivity;
import com.google.android.material.snackbar.Snackbar;

public class Register extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText usernameEditText = findViewById(R.id.new_username);
        final EditText passwordEditText = findViewById(R.id.new_password);
        final EditText firstNameEditText = findViewById(R.id.first_name);
        final EditText lastNameEditText = findViewById(R.id.last_name);
        final Button backButton = findViewById(R.id.back);
        final Button confirmButton = findViewById(R.id.confirm);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loadLogin = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(loadLogin);
            }
        });

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Register.this, "Account Created", Toast.LENGTH_SHORT).show();
                Intent loadLogin = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(loadLogin);
            }
        });
    }


}